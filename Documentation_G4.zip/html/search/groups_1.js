var searchData=
[
  ['fonctions_20partie_20texte_20principales_81',['Fonctions partie texte principales',['../group__Fonctions__prin.html',1,'']]],
  ['fonctions_20partie_20texte_20secondaires_82',['Fonctions partie texte secondaires',['../group__fonctions__sec.html',1,'']]]
];
