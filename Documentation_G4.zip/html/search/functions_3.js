var searchData=
[
  ['ecrirematricedansfichier_63',['ecrireMatriceDansFichier',['../group__Hors__spec.html#gafce8af037faf4f8ba4acd5786e94bc6a',1,'ecrireMatriceDansFichier(Groupe_Pixel_ptr groupePixel, int hauteur, int largeur, char *nomfichier):&#160;traitementImage.c'],['../group__Hors__spec.html#gafce8af037faf4f8ba4acd5786e94bc6a',1,'ecrireMatriceDansFichier(Groupe_Pixel_ptr groupePixel, int hauteur, int largeur, char *nomfichier):&#160;traitementImage.c']]]
];
