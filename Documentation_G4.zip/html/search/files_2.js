var searchData=
[
  ['solal_2ec_52',['solal.c',['../solal_8c.html',1,'']]],
  ['solal_2eh_53',['solal.h',['../solal_8h.html',1,'']]]
];
