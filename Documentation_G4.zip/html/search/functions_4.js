var searchData=
[
  ['get_5fcouleur_64',['get_couleur',['../group__Detection__image.html#gadcde61f3e99663916f038fc8acf0350a',1,'get_couleur(Groupe_Pixel_ptr groupe):&#160;traitementImage.c'],['../group__Detection__image.html#gadcde61f3e99663916f038fc8acf0350a',1,'get_couleur(Groupe_Pixel_ptr groupe):&#160;traitementImage.c']]]
];
