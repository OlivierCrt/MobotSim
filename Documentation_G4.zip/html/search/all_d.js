var searchData=
[
  ['tolowercase_38',['toLowercase',['../group__fonctions__sec.html#gad9e5ea51066a769fe32ed4e876c74cbc',1,'toLowercase(char *str):&#160;ismael.c'],['../group__fonctions__sec.html#gad9e5ea51066a769fe32ed4e876c74cbc',1,'toLowercase(char *str):&#160;ismael.c']]],
  ['traitement_20de_20commmandes_39',['Traitement de commmandes',['../group__gtrait.html',1,'']]],
  ['trouver_5fmilieu_40',['trouver_milieu',['../group__Detection__image.html#ga1453299510016e982e16b33c8961e453',1,'trouver_milieu(Groupe_Pixel_ptr groupe, int largeur, int hauteur):&#160;olivier.c'],['../group__Detection__image.html#ga1453299510016e982e16b33c8961e453',1,'trouver_milieu(Groupe_Pixel_ptr groupe, int largeur, int hauteur):&#160;olivier.c']]],
  ['trouver_5frayon_41',['trouver_rayon',['../group__Detection__image.html#gae5585be3718a80afff7078870bab5c6b',1,'trouver_rayon(Groupe_Pixel_ptr objet, int largeur, int hauteur):&#160;olivier.c'],['../group__Detection__image.html#gae5585be3718a80afff7078870bab5c6b',1,'trouver_rayon(Groupe_Pixel_ptr objet, int largeur, int hauteur):&#160;olivier.c']]],
  ['trouverleplusgros_42',['trouverLePlusGros',['../group__Hors__spec.html#ga88c06ab8e7cadb501f7f5e745f70cbdc',1,'trouverLePlusGros(int **matrice, int hauteur, int largeur):&#160;olivier.c'],['../group__Hors__spec.html#ga88c06ab8e7cadb501f7f5e745f70cbdc',1,'trouverLePlusGros(int **matrice, int hauteur, int largeur):&#160;olivier.c']]]
];
