var searchData=
[
  ['get_5fcouleur_16',['get_couleur',['../group__Detection__image.html#gadcde61f3e99663916f038fc8acf0350a',1,'get_couleur(Groupe_Pixel_ptr groupe):&#160;traitementImage.c'],['../group__Detection__image.html#gadcde61f3e99663916f038fc8acf0350a',1,'get_couleur(Groupe_Pixel_ptr groupe):&#160;traitementImage.c']]],
  ['groupe_5fpixel_5fs_17',['Groupe_Pixel_s',['../structGroupe__Pixel__s.html',1,'']]],
  ['groupe_5fpixel_5fs_18',['Groupe_pixel_s',['../structGroupe__pixel__s.html',1,'']]]
];
