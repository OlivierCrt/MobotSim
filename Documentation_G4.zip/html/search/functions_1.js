var searchData=
[
  ['changementdebase_56',['changementDeBase',['../group__gtrait.html#ga237944e0c7a0d68bbf040677e0180659',1,'changementDeBase(int *coin_HD, int *milieu_bleu, int *milieu_jaune, int *milieu_orange):&#160;traitementCommande.c'],['../group__gtrait.html#ga237944e0c7a0d68bbf040677e0180659',1,'changementDeBase(int *coin_HD, int *milieu_bleu, int *milieu_jaune, int *milieu_orange):&#160;traitementCommande.c']]],
  ['convertdouble_57',['convertDouble',['../group__fonctions__sec.html#ga57b9365708df2fd2d05e4c9984b917e2',1,'convertDouble(char *str):&#160;traitementTexte.c'],['../group__fonctions__sec.html#ga57b9365708df2fd2d05e4c9984b917e2',1,'convertDouble(char *str):&#160;traitementTexte.c']]]
];
