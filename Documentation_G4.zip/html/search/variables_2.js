var searchData=
[
  ['nbpixel_5fg_79',['nbpixel_g',['../structGroupe__Pixel__s.html#a8530f71d0778e43eaffef8e5f01e0496',1,'Groupe_Pixel_s']]]
];
